"""Пакет сервиса парсинга для обновления курсов валют."""

from .config import ParserConfig  # noqa: F401
from .updater import RatesUpdater  # noqa: F401
